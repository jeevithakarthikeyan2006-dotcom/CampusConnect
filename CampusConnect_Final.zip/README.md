# CampusConnect - Final Full Stack Project

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: MongoDB
- API: REST

## Run Backend
Open Terminal 1:

```bash
cd backend
npm install
node server.js
```

You should see:
- MongoDB connected successfully
- CampusConnect server running on http://localhost:5000

## Run Frontend
Open Terminal 2:

```bash
cd frontend
npm install
npm run dev
```

Open the Local URL shown by Vite, usually:
http://localhost:5173

## Features
- Home landing page
- Dashboard
- Student registration
- MongoDB student storage
- Student search
- Student deletion
- Projects section
- Events and opportunities
- Profile section
- Responsive design
- REST API
