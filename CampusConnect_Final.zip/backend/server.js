const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI =
  process.env.MONGO_URI || "mongodb://127.0.0.1:27017/campusconnect";

app.use(cors());
app.use(express.json());

const studentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true },
    department: { type: String, required: true, trim: true },
    year: { type: String, required: true, trim: true },
    skill: { type: String, required: true, trim: true },
    bio: { type: String, default: "", trim: true }
  },
  { timestamps: true }
);

const Student = mongoose.model("Student", studentSchema);

app.get("/", (req, res) => {
  res.json({
    message: "CampusConnect API is running",
    endpoints: ["/api/students", "/api/stats"]
  });
});

app.get("/api/students", async (req, res) => {
  try {
    const students = await Student.find().sort({ createdAt: -1 });
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/students", async (req, res) => {
  try {
    const { name, email, department, year, skill, bio } = req.body;

    if (!name || !email || !department || !year || !skill) {
      return res.status(400).json({ message: "Please fill all required fields." });
    }

    const existing = await Student.findOne({ email });
    if (existing) {
      return res.status(409).json({ message: "A student with this email already exists." });
    }

    const student = await Student.create({
      name,
      email,
      department,
      year,
      skill,
      bio: bio || ""
    });

    res.status(201).json(student);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.put("/api/students/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!student) {
      return res.status(404).json({ message: "Student not found." });
    }

    res.json(student);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.delete("/api/students/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);

    if (!student) {
      return res.status(404).json({ message: "Student not found." });
    }

    res.json({ message: "Student deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/stats", async (req, res) => {
  try {
    const totalStudents = await Student.countDocuments();
    const departments = await Student.distinct("department");

    res.json({
      totalStudents,
      departments: departments.length,
      opportunities: 8,
      projects: 12
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("MongoDB connected successfully");
    app.listen(PORT, () => {
      console.log(`CampusConnect server running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  });
