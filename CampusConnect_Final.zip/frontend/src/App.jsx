import { useEffect, useMemo, useState } from "react";

const API = "http://localhost:5000/api";

const demoEvents = [
  { title: "Campus Hackathon 2026", date: "Oct 12", type: "Hackathon", icon: "💻" },
  { title: "Tech Career Connect", date: "Oct 18", type: "Career", icon: "🚀" },
  { title: "UI/UX Design Sprint", date: "Oct 25", type: "Workshop", icon: "🎨" },
  { title: "AI Project Expo", date: "Nov 02", type: "Expo", icon: "🤖" }
];

const demoProjects = [
  { title: "Smart Campus", team: "4 members", tech: "MERN • IoT", icon: "🏫" },
  { title: "Food Saver", team: "3 members", tech: "React • Firebase", icon: "🍱" },
  { title: "EcoWatt", team: "4 members", tech: "ESP32 • MQTT", icon: "⚡" },
  { title: "Study Buddy", team: "2 members", tech: "AI • Web", icon: "📚" }
];

function App() {
  const [page, setPage] = useState(window.location.hash.replace("#", "") || "home");
  const [students, setStudents] = useState([]);
  const [stats, setStats] = useState({
    totalStudents: 0,
    departments: 0,
    opportunities: 8,
    projects: 12
  });
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    department: "",
    year: "",
    skill: "",
    bio: ""
  });

  useEffect(() => {
    const onHash = () => setPage(window.location.hash.replace("#", "") || "home");
    window.addEventListener("hashchange", onHash);
    loadData();
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  async function loadData() {
    try {
      const [studentRes, statsRes] = await Promise.all([
        fetch(`${API}/students`),
        fetch(`${API}/stats`)
      ]);
      const studentData = await studentRes.json();
      const statsData = await statsRes.json();
      setStudents(Array.isArray(studentData) ? studentData : []);
      setStats(statsData);
    } catch {
      setNotice("Backend is not connected. Start the backend terminal first.");
    } finally {
      setLoading(false);
    }
  }

  function navigate(target) {
    window.location.hash = target;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function updateForm(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function registerStudent(e) {
    e.preventDefault();

    if (!form.name || !form.email || !form.department || !form.year || !form.skill) {
      setNotice("Please fill all required fields.");
      return;
    }

    try {
      const res = await fetch(`${API}/students`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      const data = await res.json();

      if (!res.ok) {
        setNotice(data.message || "Registration failed.");
        return;
      }

      setStudents((old) => [data, ...old]);
      setStats((old) => ({ ...old, totalStudents: old.totalStudents + 1 }));
      setForm({
        name: "",
        email: "",
        department: "",
        year: "",
        skill: "",
        bio: ""
      });
      setShowForm(false);
      setNotice("Student profile created successfully!");
      navigate("students");
    } catch {
      setNotice("Could not connect to the backend.");
    }
  }

  async function deleteStudent(id) {
    if (!window.confirm("Delete this student profile?")) return;

    try {
      const res = await fetch(`${API}/students/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();

      setStudents((old) => old.filter((student) => student._id !== id));
      setStats((old) => ({
        ...old,
        totalStudents: Math.max(0, old.totalStudents - 1)
      }));
      setNotice("Student profile deleted.");
    } catch {
      setNotice("Could not delete the profile.");
    }
  }

  const filteredStudents = useMemo(() => {
    const value = search.toLowerCase().trim();
    if (!value) return students;

    return students.filter((student) =>
      `${student.name} ${student.department} ${student.skill} ${student.year}`
        .toLowerCase()
        .includes(value)
    );
  }, [students, search]);

  const initials = (name = "") =>
    name
      .split(" ")
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toUpperCase();

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => navigate("home")}>
          <span className="brand-mark">C</span>
          <span>
            Campus<span>Connect</span>
          </span>
        </button>

        <nav className="nav">
          {["home", "dashboard", "students", "projects", "events"].map((item) => (
            <button
              key={item}
              className={page === item ? "active" : ""}
              onClick={() => navigate(item)}
            >
              {item[0].toUpperCase() + item.slice(1)}
            </button>
          ))}
        </nav>

        <button className="nav-cta" onClick={() => navigate("profile")}>
          My Profile
        </button>
      </header>

      {notice && (
        <div className="notice">
          <span>{notice}</span>
          <button onClick={() => setNotice("")}>×</button>
        </div>
      )}

      <main>
        {page === "home" && (
          <>
            <section className="hero-page">
              <div className="hero-copy">
                <div className="eyebrow">SMART STUDENT COMMUNITY</div>
                <h1>
                  Your campus.
                  <br />
                  <span>One connected community.</span>
                </h1>
                <p>
                  CampusConnect brings students, skills, projects, events and
                  opportunities together in one simple platform.
                </p>
                <div className="hero-actions">
                  <button className="primary-btn" onClick={() => setShowForm(true)}>
                    Join CampusConnect →
                  </button>
                  <button className="secondary-btn" onClick={() => navigate("students")}>
                    Explore Students
                  </button>
                </div>
                <div className="mini-stats">
                  <div><strong>{stats.totalStudents}+</strong><span>Students</span></div>
                  <div><strong>{stats.projects}+</strong><span>Projects</span></div>
                  <div><strong>{stats.opportunities}+</strong><span>Opportunities</span></div>
                </div>
              </div>

              <div className="hero-visual">
                <div className="orbit-card card-one">🤝 <b>Team Up</b><small>Find project partners</small></div>
                <div className="orbit-card card-two">💡 <b>Share Skills</b><small>Show what you can do</small></div>
                <div className="center-campus">
                  <div className="campus-icon">🎓</div>
                  <b>CampusConnect</b>
                  <small>Connect • Collaborate • Grow</small>
                </div>
              </div>
            </section>

            <section className="section">
              <div className="section-title">
                <div><span>WHY CAMPUSCONNECT</span><h2>Everything students need.</h2></div>
                <p>A single digital space for campus networking and collaboration.</p>
              </div>
              <div className="feature-grid">
                {[
                  ["👥", "Student Networking", "Discover students from different departments and build meaningful connections."],
                  ["🧠", "Skill Discovery", "Find teammates based on technical, creative and communication skills."],
                  ["🚀", "Opportunities", "Keep track of events, projects, workshops and career opportunities."],
                  ["📊", "Student Dashboard", "See community statistics and your campus activity in one place."]
                ].map(([icon, title, text]) => (
                  <article className="feature-card" key={title}>
                    <div className="feature-icon">{icon}</div>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </article>
                ))}
              </div>
            </section>

            <section className="dark-banner">
              <div>
                <span>READY TO CONNECT?</span>
                <h2>Build your campus network today.</h2>
              </div>
              <button className="light-btn" onClick={() => setShowForm(true)}>Create Student Profile →</button>
            </section>
          </>
        )}

        {page === "dashboard" && (
          <section className="page-section">
            <div className="page-heading">
              <div><span>OVERVIEW</span><h1>Campus Dashboard</h1><p>A quick view of the CampusConnect community.</p></div>
              <button className="primary-btn" onClick={() => setShowForm(true)}>+ Add Student</button>
            </div>

            <div className="stat-grid">
              <div className="stat-card"><span>👥</span><b>{stats.totalStudents}</b><p>Registered Students</p></div>
              <div className="stat-card"><span>🏢</span><b>{stats.departments}</b><p>Departments</p></div>
              <div className="stat-card"><span>🚀</span><b>{stats.opportunities}</b><p>Opportunities</p></div>
              <div className="stat-card"><span>💻</span><b>{stats.projects}</b><p>Projects</p></div>
            </div>

            <div className="dashboard-grid">
              <div className="panel">
                <div className="panel-head"><h3>Recent Students</h3><button onClick={() => navigate("students")}>View all →</button></div>
                {students.slice(0, 4).map((student) => (
                  <div className="recent-row" key={student._id}>
                    <div className="avatar">{initials(student.name)}</div>
                    <div><b>{student.name}</b><small>{student.department} • {student.skill}</small></div>
                  </div>
                ))}
                {!students.length && <div className="empty">No students registered yet.</div>}
              </div>

              <div className="panel">
                <div className="panel-head"><h3>Upcoming Events</h3><button onClick={() => navigate("events")}>See all →</button></div>
                {demoEvents.slice(0, 3).map((event) => (
                  <div className="event-row" key={event.title}>
                    <span className="event-icon">{event.icon}</span>
                    <div><b>{event.title}</b><small>{event.date} • {event.type}</small></div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {page === "students" && (
          <section className="page-section">
            <div className="page-heading">
              <div><span>COMMUNITY</span><h1>Explore Students</h1><p>Find students by name, department, year or skill.</p></div>
              <button className="primary-btn" onClick={() => setShowForm(true)}>+ Register</button>
            </div>

            <div className="search-bar">
              🔎
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search students, departments or skills..."
              />
            </div>

            {loading ? <div className="empty">Loading students...</div> : (
              <div className="people-grid">
                {filteredStudents.map((student) => (
                  <article className="person-card" key={student._id}>
                    <div className="person-top">
                      <div className="big-avatar">{initials(student.name)}</div>
                      <div><h3>{student.name}</h3><p>{student.email}</p></div>
                    </div>
                    <div className="pill-row"><span>{student.department}</span><span>{student.year}</span></div>
                    <p className="bio">{student.bio || "CampusConnect student profile."}</p>
                    <div className="skill-line"><b>Skill</b><span>{student.skill}</span></div>
                    <button className="delete-link" onClick={() => deleteStudent(student._id)}>Delete profile</button>
                  </article>
                ))}
              </div>
            )}

            {!loading && !filteredStudents.length && (
              <div className="empty large-empty">
                <div>👥</div>
                <h3>No matching students</h3>
                <p>Try another search or create a new profile.</p>
              </div>
            )}
          </section>
        )}

        {page === "projects" && (
          <section className="page-section">
            <div className="page-heading">
              <div><span>COLLABORATION</span><h1>Student Projects</h1><p>Explore projects and discover ideas to collaborate on.</p></div>
              <button className="primary-btn" onClick={() => setNotice("Project creation can be connected to MongoDB next.")}>+ New Project</button>
            </div>
            <div className="project-grid">
              {demoProjects.map((project) => (
                <article className="project-card" key={project.title}>
                  <div className="project-icon">{project.icon}</div>
                  <span className="project-status">ACTIVE PROJECT</span>
                  <h3>{project.title}</h3>
                  <p>A collaborative student project built around practical campus needs and technology.</p>
                  <div className="project-meta"><span>👥 {project.team}</span><span>⚙ {project.tech}</span></div>
                  <button className="outline-btn" onClick={() => setNotice(`${project.title} selected for collaboration.`)}>View Project →</button>
                </article>
              ))}
            </div>
          </section>
        )}

        {page === "events" && (
          <section className="page-section">
            <div className="page-heading">
              <div><span>CAMPUS CALENDAR</span><h1>Events & Opportunities</h1><p>Discover activities that help you learn, build and connect.</p></div>
            </div>
            <div className="event-grid">
              {demoEvents.map((event) => (
                <article className="full-event-card" key={event.title}>
                  <div className="date-box"><b>{event.date.split(" ")[0]}</b><small>{event.date.split(" ")[1]}</small></div>
                  <div className="event-main"><span>{event.type}</span><h3>{event.title}</h3><p>Join fellow students, learn new skills and build your network.</p><button onClick={() => setNotice(`Registration interest recorded for ${event.title}.`)}>I'm Interested →</button></div>
                  <div className="event-large-icon">{event.icon}</div>
                </article>
              ))}
            </div>
          </section>
        )}

        {page === "profile" && (
          <section className="page-section profile-page">
            <div className="profile-cover">
              <div className="profile-avatar">JK</div>
              <div><span>STUDENT PROFILE</span><h1>CampusConnect Member</h1><p>Create your profile to appear in the student community.</p></div>
              <button className="light-btn" onClick={() => setShowForm(true)}>Create / Update Profile</button>
            </div>
            <div className="profile-info-grid">
              <div className="panel"><h3>What you can showcase</h3><p>Department and year</p><p>Technical and creative skills</p><p>Short student bio</p><p>Project interests</p></div>
              <div className="panel"><h3>Community benefits</h3><p>Find teammates for projects</p><p>Discover campus events</p><p>Connect across departments</p><p>Explore opportunities</p></div>
            </div>
          </section>
        )}
      </main>

      <footer>
        <div><b>Campus<span>Connect</span></b><p>Connecting students. Building opportunities.</p></div>
        <div><p>Built with React • Express • MongoDB</p><p>© 2026 CampusConnect</p></div>
      </footer>

      {showForm && (
        <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowForm(false)}>
          <form className="modal" onSubmit={registerStudent}>
            <div className="modal-head"><div><span>NEW MEMBER</span><h2>Create Student Profile</h2></div><button type="button" onClick={() => setShowForm(false)}>×</button></div>
            <div className="form-grid">
              <label>Full Name<input name="name" value={form.name} onChange={updateForm} placeholder="Enter your name" /></label>
              <label>Email<input type="email" name="email" value={form.email} onChange={updateForm} placeholder="student@example.com" /></label>
              <label>Department<select name="department" value={form.department} onChange={updateForm}><option value="">Select</option><option>CSE</option><option>ECE</option><option>EEE</option><option>MECH</option><option>CIVIL</option></select></label>
              <label>Year<select name="year" value={form.year} onChange={updateForm}><option value="">Select</option><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select></label>
              <label className="full">Main Skill<input name="skill" value={form.skill} onChange={updateForm} placeholder="Python, UI/UX, Java, Leadership..." /></label>
              <label className="full">Short Bio<textarea name="bio" value={form.bio} onChange={updateForm} placeholder="Tell the campus community about yourself..." /></label>
            </div>
            <button className="primary-btn full-btn" type="submit">Create Student Profile →</button>
          </form>
        </div>
      )}
    </div>
  );
}

export default App;
